

var https = require('https');
var fs = require('fs');

var options = {
    host:'fd22:b0fd:7c46::2',
        path: '/',
	port:4040,
	key: fs.readFileSync('ryans-key.pem'),
  	cert: fs.readFileSync('ryans-csr.pem'),
  	rejectUnauthorized: false
};

callback = function(response) {
    var str = '';
        
        //another chunk of data has been recieved, so append it to `str`
            response.on('data', function (chunk) {
                        str += chunk;
                        });
                
                //the whole response has been recieved, so we just print it out here
                    response.on('end', function () {
                    
                                console.log(str);

                                //end time
                                //elap

                                console.log('Request took:', new Date() - start, 'ms');

                                });
                               
}
// start time

var start = new Date();

https.request(options, callback).end();
