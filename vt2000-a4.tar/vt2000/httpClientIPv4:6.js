var http = require('http');
var options = {
host:'192.168.0.1',
path: '/' , 
port:4444
};

callback = function(response) {
var str = '';
//another chunk of data has been recieved, so append it to `str`
response.on('data', function (chunk) {
str += chunk;});
//the whole response has been recieved, so we just print it out here
response.on('end', function () {
                                                                                                                                                       console.log(str);
console.log('Request took:' , new Date() - start, 'ms');                                                                                                                                                                                     });
                                                                                                                                                                                        }
        
var start = new Date();                                                                                                                                                                         http.request(options, callback).end();



