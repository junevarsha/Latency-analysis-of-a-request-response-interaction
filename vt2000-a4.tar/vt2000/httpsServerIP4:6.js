var https = require("https");
var fs = require('fs');

var options = {
  key: fs.readFileSync('ryans-key.pem'),
  cert: fs.readFileSync('ryans-csr.pem')};

var fun = function(request, response) {
 response.writeHead(200, {"Content-Type": "text/html"});
 response.write("<!DOCTYPE \"html\">");
 response.write("<html><body>Hello World! Vidhi Secure</body></html>");
 response.end();
}
var server = https.createServer(options, fun);

server.listen(4040, 'fd22:b0fd:7c46::2');
console.log("Server is listening");
