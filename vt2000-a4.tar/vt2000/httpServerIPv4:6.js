var http = require("http");
var fun = function(request, response) {
 response.writeHead(200, {"Content-Type": "text/html"});
 response.write("<!DOCTYPE 'html'>");
  response.write("<html>");
  response.write("<head>");
 response.write("<title>Hey Varsha how are you doing. Welcome to USA. The education system in USA is very practical.It gives a opportunity to focus on many new feautures.</title>");
 response.write("</head>");
  response.write("<body>");
  response.write("Hello World!");
  response.write("</body>");
  response.write("</html>");
 response.end();
}
var server = http.createServer(fun);

server.listen(4444);
console.log("Server is listening");
